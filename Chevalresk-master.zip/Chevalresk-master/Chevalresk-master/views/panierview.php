<?php
$username = strtoupper($_SESSION["userName"]); //en majuscule
?>
<h1 style="text-align: center;">
    PANIER DE <?php echo $username; ?>
</h1>
<br>
<?php
//si un article est voulue ajouter au panier
if (isset($_GET['id']) || !empty($_GET['id'])) {
    $id = $_GET['id'];
    echo '
    <h4 class="container">VOULEZ VOUS AJOUTER CET ITEM DANS VOTRE PANIER ?
        <a href="">OUI</a>
        <a href="../user/billboard.php">NON</a>
    </h4>';

    $TDG = itemTDG::getInstance();
    $res = $TDG->get_all_info_by_id($id);
    $table = "<div class='container'>
    <table>";

    foreach ($res as $column => $item) {
        $idItem = $item['idItem'];
        $table .= '<tr><td id="data"><a href="' . $item['photoItem'] . '"><img class="imageItem" src="' . $item['photoItem'] . '"></a></td>';
        $table .= '<td><ul>';
        $table .= '<li><b>Nom : </b>' . $item['nomItem'] . '</li>';
        $table .= '<li><b>Quantite en stock : </b>' . $item['quantiteStockItems'] . '</li>';
        $table .= '<li><b>Type : </b>' .  $item['typeItem'] . ' </li>';
        $table .= '<li><b>Prix : </b>' . $item['prixItem'] . '</li>';
        $table .= "</ul></td></tr>";
    }

    $table .= ' </table></div>';
    echo $table;
}
?>

<div class="container">
    <h4>Article dans votre panier présentement</h4>
    <?php
    //aller chercher le panier du joueur avec son 
    $idJoueur = $_SESSION["userID"];
    $inventaire = InventaireTDG::getInstance();
    $items = $inventaire->get_all_info_by_id($idJoueur);

    
    $panier = html_table_gen($item);

    echo $panier;
?>
    <a href="">
        <h5>ACHETER</h5>
    </a><a href="">
        <h5>SUPPRIMER</h5>
    </a>
</div>