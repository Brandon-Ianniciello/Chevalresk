    <div class="center">
        <h1>S'enregistrer</h1>
        <form method="POST" action="../user.dom/register.dom.php">
            <?php
            if (isset($_GET['errmsg'])) {
                $msg_error = $_GET['errmsg'];
                echo "<div class='pt-3 text-danger'>
                    <h5><p>$msg_error</p></h5>
                </div>";
            }
            ?>

            <div class="txt_field">
                <input type="text" id="alias" name="alias" required autofocus>
                <span></span>
                <label>Alias</label>     
            </div>

            <div class="txt_field">
                <input type="text" id="nom" name="nom" required>
                <span></span>
                <label>Nom</label>       
            </div>

            <div class="txt_field">
                <input type="text" id="prénom" name="prénom" required>
                <span></span>
                <label>Prénom</label>
            </div>

            <div class="txt_field">
                <input type="email" id="email" name="email" required>
                <span></span>
                <label>Email</label>
            </div>

            <div class="txt_field">
                <input type="password" id="password" name="password" required>
                <span></span>
                <label>Mot de passe</label>          
            </div>

            <div class="txt_field">
                <input type="password" id="confirmpassword" name="confirmpassword" required>
                <span></span>
                <label>Confirmez mot de passe</label>
            </div>

            <input type="submit" value="S'enregistrer">
            <div class="Signup_link">Vous avez déjà un compte?<a href="../user/login.php"> Connectez-vous!</a></div>

        </form>
    </div>
