<div class="container">
    <nav class="rechercheCat">
        <a href="../user/billboard.php" class="itemCat">Tous les items</a>
        <a href="../user/potion.php" class="itemCat">Potion</a>
        <a href="../user/arme.php" class="itemCat">Armes</a>
        <a href="../user/armure.php" class="itemCat">Armures</a>
    </nav>
   
    <table>
        <tr>
            <!-- <td><a href="../user/potion.php">POTIONS</a></td>
            <td><a href="../user/armure.php">ARMURES</a></td>
            <td><a href="../user/arme.php">ARMES</a></td> -->
            <td><a href="../user/addItem.php">AJOUTER UN ITEM</a></td>
            <td>
                <form method='POST'>
                    <label>Recherche</label>
                    <input type='text' name='txtBox' required autofocus>
                    <button type='submit' name="search" class="btn btn-lg btn btn-dark btn-block mt-3">Rechercher</button>
                </form>
            </td>
        </tr>
        <tr>
            <!-- <form method='POST'>
            <label for='formCategorie[]'>Selectionnez une catégorie que vous souhaitez rechercher : </label><br>
                <select multiple="multiple" name="formCategorie[]">
                    <option value="A">Armure et Arme</option>
                    <option value="P">Potion</option>
                </select>
                <button type="submit" name="searchCategorie" class="btn btn-lg btn btn-dark btn-block mt-3">Choissizez une categorie</button>
            </form> -->

        </tr>
    </table>
</div>
<br>

<?php
$buyable = false;
if (validate_session()) {
    $buyable = true;
}

//afficher l'error si y'en a une
if (isset($_GET['ErrorMSG'])) {
    $msg_error = $_GET['ErrorMSG'];
    echo "<div class='pt-3 text-danger'>
        <h5>$msg_error</h5>
    </div>";
}

/*Variables */
$TDG = itemTDG::getInstance();
if (isset($_SESSION['userID']))
    $idJoueur = $_SESSION['userID'];
else
    $idJoueur = null;

/*Si il y a une recherche*/
if (isset($_POST['search'])) {
    $recherche = $_POST['search'];
    $itemName = $TDG->get_by_nom($_POST['txtBox']);
    $res = $TDG->get_all_info_by_name($itemName);
    $table = "<div class='container'><table id='itemTab'><tr><th><div><h4>RÉSULTAT POUR lA RECHERCHE : $recherche </h4></div></th></tr>";
    foreach ($res as $column => $item) {
        $idItem = $item['idItem'];
        $table .= "<tr>";
        $table .= '<td id="data">' . $item['nomItem'] . '</td>';
        if ($item['quantiteStockItems'] <= 0)
            $table .= '<td id="data"><a class="rupture_de_stock">RUPTURE DE STOCK</a></td>';
        else
            $table .= '<td id="data">' . $item['quantiteStockItems'] . '</td>';
        $table .= '<td id="data">' .  $item['typeItem'] . ' </td>';
        $table .= '<td id="data">' . $item['prixItem'] . '</td>';
        $table .= '<td id="data"><a href="' . $item['photoItem'] . '"><img class="imageItem" src="' . $item['photoItem'] . '"></a></td>';
        $table .= "<td><a href='../user/panier.php?id=$idItem idJoueur=$idJoueur'>AJOUTER AU PANIER</a></td>";
        $table .= '</tr>';
    }
    echo $table;
}
if (isset($_POST['searchCategorie'])) {
    $categorie = $_POST['formCategorie'];
    $res = $TDG->get_by_type($categorie[0]);
    $res2 = $TDG->get_all_info_by_type($res);

    $table = "<h3 class='titleType'>" . $categorie[0] . "</h3>";
    $table = "<div class='row'>";
    foreach ($res2 as $column => $item) {
        $table .= "<div class='col-4'>";
        $table .= "<div class='col'>";
        $idItem = $item['idItem'];
        $table .= '<img class="imageItem" src="' . $item['photoItem'] . '">';
        $table .= '<h4 class="nomItem">' . $item['nomItem'] . '</h4><p class="prixItem">' . $item['prixItem'] . '$</p>';
        $table .= "<a class='addPanier' href='../user/panier.php?id=$idItem idJoueur=$idJoueur'>AJOUTER AU PANIER</a>";
        $table .= '</div> </div>';
    }

    $table .= ' </table></div>';
    echo $table;
}
?>

<h3 style="text-align: center; color:#555;">TOUS LES ITEMS</h3>

<?php
$res = $TDG->get_all_items();
$table = "<div class='row'>";
foreach ($res as $column => $item) {
    $table .= "<div class='col-4'>";
    $table .= "<div class='col'>";
    $idItem = $item['idItem'];
    $table .= '<img class="imageItem" src="' . $item['photoItem'] . '">';
    if ($item['quantiteStockItems'] <= 0){
        $table .= '<td id="data"><a style="color:red;">RUPTURE DE STOCK</a></td>';
        $table .= '<h4 class="nomItem">' . $item['nomItem'] . '</h4><p class="prixItem">' . $item['prixItem'] . '$</p>';
    }
       
    else{
        $table .= '<td id="data">Qt:' . $item['quantiteStockItems'] . '</td>';
        $table .= '<h4 class="nomItem">' . $item['nomItem'] . '</h4><p class="prixItem">' . $item['prixItem'] . '$</p>';    $table .= "<a class='addPanier' href='../user/panier.php?id=$idItem idJoueur=$idJoueur'>AJOUTER AU PANIER</a>";
    }
       

    $table .= '</div> </div>';
}

$table .= ' </table></div>';
echo $table;

?>