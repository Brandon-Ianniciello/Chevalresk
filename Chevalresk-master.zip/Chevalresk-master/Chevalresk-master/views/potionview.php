<div class="container">
    <table>
        <tr style="padding: 15px;text-align: center;">
            <td><a href="../user/billboard.php">ITEMS</a></td>
            <th>POTIONS</th>
            <td><a href="../user/armure.php">ARMURES</a></td>
            <td><a href="../user/arme.php">ARMES</a></td>
        </tr>
    </table>
</div>
<br>

<?php
$buyable = false;
if (validate_session()) 
    $buyable = true;

/*AFFICHER TOUT LES POTIONS*/
$TDG = PotionTDG::getInstance();
$res = $TDG->get_all_potions();
$table = html_table_gen($res);

echo $table;
?>