<?php
/*get l'id dans l'url */
if (isset($_GET['id'])) {
    $id = $_GET['id'];
} else {
    header("Location: ../user/billboard.php");
    die();
}

/* Évaluations */
$évalTDG = EvaluationTDG::getInstance();
$evaluations = $évalTDG->get_all_info_by_idItem($id);

/*Item*/
$itemTDG = itemTDG::getInstance();
$res = $itemTDG->get_all_info_by_id($id);

/*Joueur*/
$joueurTDG = JoueurTDG::getInstance();

$photoItem = $res[0]['photoItem'];
$nomITem = $res[0]['nomItem'];

$table = "<div class='container'><table id='itemTab'>";

/*variables*/
$uneÉtoile = 0;
$deuxÉtoiles = 0;
$troisÉtoiles = 0;
$quatreÉtoiles = 0;
$cinqÉtoiles = 0;

?>

<h3 style="text-align: center; color:#555;">Détails sur <?php echo ($nomITem); ?></h3>

<?PHP
foreach ($res as $column => $item) {
    $idItem = $item['idItem'];
    $table .= '<tr class="intro">
        <td id="data">
        <a href="' . $item['photoItem'] . '">
        <img class="imageItem" src="' . $item['photoItem'] . '">
        </a>
        </td>';
    $table .= '<td><ul>';
    $table .= '<li><b>Nom : </b>' . $item['nomItem'] . '</li>';
    $table .= '<li><b>Quantite en stock : </b>' . $item['quantiteStockItems'] . '</li>';
    $table .= '<li><b>Type : </b>' .  $item['typeItem'] . ' </li>';
    $table .= '<li><b>Prix : </b>' . $item['prixItem'] . '</li>';
    $table .= "</ul></td>";
    $table .= "
    <td style='border:1 px solid black;paddin:10px;'> 
        <div class='container'>
        <form class='form-signin' method='POST' action='../user.dom/addpanier.dom.php?idItem=" . $id . "'>
            <input type='number' name='Quantite' class='form-control' placeholder='Quantite' required autofocus>
            <br>
            <h4>AJOUTER CET ITEM DANS VOTRE PANIER ?</h4>
            <button type='submit'>OUI</a></button>
        </form>
        <br>
        <button><a href='../user/billboard.php'>NON</a></button>
        </div>
    <td>";
    $table .= "<tr style='width:100%;'><td><h2 style='color:#555; text-align:justify;'>Évaluations</h2></td></tr>";

    /* Display les commentaires */
    // if (isset($evaluations['Commentaire']) && $evaluations['Commentaire'] != null) {
    foreach ($evaluations as $commetnaire => $e) {
        $res = $joueurTDG->get_all_info_by_id($e['idJoueur']);

        $idEvaluation = $evaluations[0]['idEvaluation'];

        if (isset($res[0]['urlPhotoProfil']))
            $url = $res[0]['urlPhotoProfil'];
        else
            $url = '../img/no_profile_pic.png';

        if (isset($res[0]['alias']))
            $alias = $res[0]['alias'];
        else
            $alias = "Stranger";

        $etoiles = $e['NbrÉtoile'];


        if ($etoiles == 1) {
            $uneÉtoile++;
            $uneÉtoile = floor(($uneÉtoile / $etoiles) * 100);
        }
        if ($etoiles == 2) {
            $deuxÉtoiles++;
            $deuxÉtoiles = floor(($deuxÉtoiles / $etoiles) * 100);
        }
        if ($etoiles == 3) {
            $troisÉtoiles++;
            $troisÉtoiles = floor(($troisÉtoiles / $etoiles) * 100);
        }

        if ($etoiles == 4) {
            $quatreÉtoiles++;
            $quatreÉtoiles = floor(($troisÉtoiles / $etoiles) * 100);
        }
        if ($etoiles == 5) {
            $cinqÉtoiles++;
            $cinqÉtoiles = floor(($cinqÉtoiles / $etoiles) * 100);
        }

        $table .= "
          
            <tr class='intro'>
                <td style='background-color:beige;text-align:justify;'>
                    <img class='rounded-circle' style='width:30px;height:30px;'src='" . $url . "'>
                    <b>" . $res[0]['alias'] . "</b><br>
                    <span> Commentaire : " . $e['Commentaire'] . " </span><br>
                    <span> Evaluation : " . $e['NbrÉtoile'] . "/5 </span><br>";

        if ($_SESSION['isAdmin'] == 1 || $_SESSION['userID'] == $res[0]['idJoueur']) {
            $table .= "
                    <button type='button' class='btn btn-danger btn-sm'>
                        <a style='color:white' href='../user.dom/deleteEvaluations.dom.php?idEvaluation=$idEvaluation'>
                            <span class='glyphicon glyphicon-remove'></span> Supprimer 
                        </a>
                    </button>
                ";
        }

        $table .= "</td>";
    }
    //}
    // else{
    //     $table.="<td>Aucunes évaluations :(</td>";
    //}
}

$table .= "
<tr class='container'>
<td>" . $uneÉtoile . "% des personnes ont donné 1 étoiles</td>
</tr>
<tr class='container'>
<td>" . $deuxÉtoiles . "% des personnes ont donné 2 étoiles</td>
</tr>
<tr class='container'>
<td>" . $troisÉtoiles . "% des personnes ont donné 3 étoiles</td>
</tr>
<tr class='container'>
<td>" . $quatreÉtoiles . "% des personnes ont donné 4 étoiles</td>
</tr>
<tr class='container'>
<td>" . $cinqÉtoiles . "% des personnes ont donné 5 étoiles</td>
</tr>
";

$table .= "</tr></table></tr></table></div>";
echo $table;
?>