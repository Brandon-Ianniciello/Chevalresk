<?php
/*get l'id dans l'url */
if (isset($_GET['id'])) {
    $id = $_GET['id'];
} else {
    header("Location: ../user/billboard.php");
    die();
}

/* Évaluations */
$évalTDG = EvaluationTDG::getInstance();
$evaluations = $évalTDG->get_all_info_by_idItem($id);

/*Item*/
$itemTDG = itemTDG::getInstance();
$res = $itemTDG->get_all_info_by_id($id);

/*Joueur*/
$joueurTDG = JoueurTDG::getInstance();

/*si l'item existe pas */
if (!isset($res[0]['nomItem'])) {
    header("Location: ../user/billboard.php");
    die();
}
$photoItem = $res[0]['photoItem'];
$nomITem = $res[0]['nomItem'];


$table = "<div class='container'><table id='itemTab'>";

/*variables*/
$uneÉtoile = 0;
$deuxÉtoiles = 0;
$troisÉtoiles = 0;
$quatreÉtoiles = 0;
$cinqÉtoiles = 0;

$one_eval = 0;
$two_eval = 0;
$three_eval = 0;
$four_eval = 0;
$five_eval = 0;

$etoiles = 0;

$nbrÉvalutaions = 0;

?>

<h3 style="text-align: center; color:#555;">Détails sur <?php echo ($nomITem); ?></h3>

<?PHP
foreach ($res as $column => $item) {
    $idItem = $item['idItem'];
    $quantite = $item['quantiteStockItems'];
    $table .= '<tr class="intro">
        <td id="data">
        <a href="' . $item['photoItem'] . '">
        <img class="imageItem" src="' . $item['photoItem'] . '">
        </a>
        </td>';
    $table .= '<td><ul>';
    $table .= '<li><b>Nom : </b>' . $item['nomItem'] . '</li>';
    $table .= '<li><b>Quantite en stock : </b>' . $quantite . '</li>';
    $table .= '<li><b>Type : </b>' .  $item['typeItem'] . ' </li>';
    $table .= '<li><b>Prix : </b>' . $item['prixItem'] . '</li>';
    $table .= "</ul></td>";
    $table .= "
    <td style='border:1 px solid black;paddin:10px;'> 
        <div class='container'>
        <form class='form-signin' method='POST' action='../user.dom/addpanier.dom.php?idItem=" . $id . "'>
            <input min=1 max=$quantite type='number' name='Quantite' class='form-control' placeholder='Quantite' required autofocus>
            <br>
            <h4>AJOUTER CET ITEM DANS VOTRE PANIER ?</h4>
            <button type='submit'>OUI</a></button>
        </form>
        <br>
        <button><a href='../user/billboard.php'>NON</a></button>
        </div>
    <td>";
    $table .= "<tr style='width:100%;'><td><h2 style='color:#555; text-align:justify;'>Évaluations</h2></td></tr>";

    /* Display les commentaires */
    foreach ($evaluations as $commetnaire => $e) {
        $res = $joueurTDG->get_all_info_by_id($e['idJoueur']);

        $idEvaluation = $evaluations[0]['idEvaluation'];

        if (isset($res[0]['urlPhotoProfil']))
            $url = $res[0]['urlPhotoProfil'];
        else
            $url = '../img/no_profile_pic.png';

        if (isset($res[0]['alias']))
            $alias = $res[0]['alias'];
        else
            $alias = "Stranger";

        $etoiles = $e['NbrÉtoile'];
        $nbrÉvalutaions++;

        if ($etoiles == 1) {
            $uneÉtoile++;
            $one_eval = round((($uneÉtoile / $nbrÉvalutaions) * 100), 2);
        }
        if ($etoiles == 2) {
            $deuxÉtoiles++;
            $two_eval = round((($deuxÉtoiles / $nbrÉvalutaions) * 100), 2);
        }
        if ($etoiles == 3) {
            $troisÉtoiles++;
            $three_eval = round((($troisÉtoiles / $nbrÉvalutaions) * 100), 2);
        }

        if ($etoiles == 4) {
            $quatreÉtoiles++;
            $four_eval = round((($quatreÉtoiles / $nbrÉvalutaions) * 100), 2);
        }
        if ($etoiles == 5) {
            $cinqÉtoiles++;
            $five_eval = round((($cinqÉtoiles / $nbrÉvalutaions) * 100), 2);
        }

        $table .= " 
            <tr class='intro'>
                <td style='background-color:white;text-align:justify;'>
                    <img class='rounded-circle' style='width:30px;height:30px;'src='" . $url . "'>
                    <b>" . $res[0]['alias'] . "</b><br>
                    <span> Commentaire : " . $e['Commentaire'] . " </span><br>
                    <span> Evaluation : " . $e['NbrÉtoile'] . "/5 </span><br>
                    <span> Evaluation : <div class='rateyo' id= 'rating'
                    data-rateyo-rating='" . $e['NbrÉtoile'] . "'
                    data-rateyo-read-only='true'
                    >
                    </div></span><br>";


        if ($_SESSION['isAdmin'] == 1 || $_SESSION['userID'] == $res[0]['idJoueur']) {
            $table .= "
            <a style='color:white' href='../user.dom/deleteEvaluations.dom.php?idEvaluation=$idEvaluation'>
                <button type='button' class='btn btn-danger btn-sm'>
                    <i class='trash icon'></i>
                </button>
            </a>";
        }

        $table .= "</td>";
    }
}
if ($etoiles > 0) {
    $table .= "
<tr class='container'>
<td>" . $nbrÉvalutaions . " évaluations au total</td>
</tr>
<tr class='container'>
<td>" . $one_eval . "% des personnes ont donné 1 étoiles</td>
</tr>
<tr class='container'>
<td>" . $two_eval . "% des personnes ont donné 2 étoiles</td>
</tr>
<tr class='container'>
<td>" . $three_eval . "% des personnes ont donné 3 étoiles</td>
</tr>
<tr class='container'>
<td>" . $four_eval . "% des personnes ont donné 4 étoiles</td>
</tr>
<tr class='container'>
<td>" . $five_eval . "% des personnes ont donné 5 étoiles</td>
</tr>
";
} else if ($etoiles <= 0) {
    $table .= "
<tr class='container'>
<td>Aucune évaluations :(</td>
</tr>";
}

$table .= "</tr></table></tr></table></div>";
echo $table;
?>