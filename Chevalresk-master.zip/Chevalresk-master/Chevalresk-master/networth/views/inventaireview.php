<?php
//afficher l'error si y'en a une
if (isset($_GET['ErrorMSG'])) {
    $msg_error = $_GET['ErrorMSG'];
    echo "<div class='pt-3 text-danger'>
        <h5>$msg_error</h5>
    </div>";
}

if (isset($_SESSION['isAdmin']))
    $isAdmin = $_SESSION['isAdmin'];
else
    $isAdmin = 0;

if(isset($_GET['alias']))
    $alias = $_GET['alias'];
else
    $alias = $_SESSION['userName'];
?>

<div class="container">
    <div style="border-style: inset;">
        <?php

        /*variables*/
        $nbrItemsInventaire = 0;
        $table = "<div class='container'><table id='itemTab'>";

        if ($isAdmin) {
            
            $inventaire = InventaireTDG::getInstance();
            $itemTDG = itemTDG::getInstance();
            $items = $inventaire->get_all_info_by_alias($alias);

        } else /*si ce n'est pas l'admin */ {
            
            $idJoueur = $_SESSION["userID"];
            $alias = $_SESSION['userName'];

            $inventaire = InventaireTDG::getInstance();
            $itemTDG = itemTDG::getInstance();
            $items = $inventaire->get_all_info_by_id($idJoueur);
        }

        //si l'inventaire est vide
        if (empty($items)) {
            $table .= "<tr><th>Aucun article présentement :(</th></tr>";
        }
        
        //si l'inventaire contient un item
        else if (isset($items)) {
            echo (" <h4>Présentement dans l'inventaire de $alias</h4><hr>");
            $table .= "
                    <tr style='text-align:center;'>
                    <th></th>
                    <th>Nom</th>
                    <th>Quantite en stock</th>
                    <th>Prix</th>
                    <th></th>
                    <th></th></hr></tr>
                ";

            foreach ($items as $idItem) {
                $id = $idItem['idItem'];
                $res = $itemTDG->get_all_info_by_id($id);
                $quantite = $inventaire->get_quantite_by_idItem($id);
                $quantite = ($quantite['Quantite']);

                /* Évaluations */
                $évalTDG = EvaluationTDG::getInstance();
                $evaluations = $évalTDG->get_all_info_by_idItem($id);

                foreach ($res as $column => $item) {
                    $idItem = $item['idItem'];
                    $table .= "<tr>";
                    $table .= "
                        <td id='data'>
                            <button type='button' class='btn btn-danger btn-sm'>
                                <a style='color:white' href='../user.dom/deleteinventaire.dom.php?idItem=$idItem'>
                                    <i class='trash icon'></i>
                                </a>
                            </button>
                        </td>";
                        
                    $table .= '<td id="data">' . $item['nomItem'] . '</td>';
                    $table .= '<td id="data">' . $item['quantiteStockItems'] . '</td>';
                    $table .= '<td id="data">' . $item['prixItem'] . '</td>';


                    $table .= '
                        <td id="data">
                            <a href="../user/details?id='. $idItem .'">
                                <img class="imageItem" src="' . $item['photoItem'] . '">
                            </a>
                        </td>';

                    /*ajouter une évaluation*/
                    $table .= '
                        <td style="background-color:beige;text-align:justify;padding-top:20px;">
                            <table class="container">
                            <form method="POST" action="../user.dom/addEvalutations.dom.php?idItem=' . $idItem . '">
                            <tr>
                                <td id="data">
                                    <h4>Ajouter un commentaire</h4>
                                    <textarea cols="20px" rows="5px" name="commentaire" placeholder="Commentez ici..." required autofocus></textarea>
                                    <h4>Rating</h4>
                                        <div class="container">
                                            <input type="radio" class="RatingBar" value="1" required autofocus/>
                                        </div>
                                </td>
                            </tr>
                            <tr>
                                <td id="data">
                                    
                                    <input class="" value="Évaluer" type="submit" name="submitRating">
                                </td>
                            </tr>
                            </table>
                            </form>
                        </td>';

                    $table .= '</tr>';
                    $nbrItemsInventaire++;
                }
            }
        }
        if (isset($_SESSION["nbrItemsInventaire"]))
            $_SESSION["nbrItemsInventaire"] = $nbrItemsInventaire;
        $table .= ' </table></div>';

        echo $table;
        ?>
    </div>
    <br>
    <a href="../user/billboard.php">Retourner à la liste</a>
</div>
</hr>