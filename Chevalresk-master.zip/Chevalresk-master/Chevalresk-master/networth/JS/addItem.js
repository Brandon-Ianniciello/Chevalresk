/*Variables */

let boutonArme = document.getElementById("Arme")
boutonArme.addEventListener('click', AppartionTypeItem)

let boutonRessource = document.getElementById("Ressource")
boutonRessource.addEventListener('click', AppartionTypeItem)

let boutonArmure = document.getElementById("Armure")
boutonArmure.addEventListener('click', AppartionTypeItem)

let boutonPotion = document.getElementById("Potion")
boutonPotion.addEventListener('click', AppartionTypeItem)

/*Fonction qui fait apparaître le form pour le type */
function AppartionTypeItem() {
    document.getElementById("FormulaireAddItem").addEventListener("submit", () => {
        if (boutonArme.checked)
            console.log("bouton arme cliqué")
        if (boutonArmure)
            console.log("bouton armure cliqué")

    })
}
