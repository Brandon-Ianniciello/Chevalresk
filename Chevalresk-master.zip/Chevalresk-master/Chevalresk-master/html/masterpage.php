<?php

//si l'utilisateur est connecté
if ($sess_status) {
    
    if (isset($_SESSION["userProfileImage"])){
        $urlPhotoProfil = $_SESSION["userProfileImage"];
        $solde = $_SESSION["userSolde"];
    }
    else
        $urlPhotoProfil = "";

    if (isset($_SESSION["username"]))
    {
        $username = $_SESSION["username"];
        $solde = $_SESSION["userSolde"];
    }
    else
        $username = "";

        $nav = '
        <h1 id="titre">CHEVALRESK</h1>
            <ul class="navList">
                <li class="navItem"><a href="../user.dom/logout.dom.php" class="navA">Déconnexion</a></li>
                <li class="navItem">
                    <a href="../user/profile.php" class="navA">
                        <img class="rounded-circle"style="width:30px;height:30px;" src="' . $urlPhotoProfil . '">
                        Profile
                    </a>
                </li>
                <li class="navItem"><a href="../user/panier.php" class="navA">Panier</a></li>
                <li class="navItem"><a href="../user/inventaire.php" class="navA">Inventaire</a></li>
                <li class="navItem"><a href="../user/billboard.php" class="navA">Items</a></li>
                <li class="navItem"><span class="spanA" style="color:white;">Solde:'. $solde.'$ </span></li>
            </ul>
    ' ;
}
//si l'utilisateur n'est pas connecté
else {
    $nav = '
        <h1 id="titre">CHEVALRESK</h1>
            <ul class="navList">
                <li class="navItem"><a href="../user/billboard.php"  class="navA">Items</a></li>
                <li class="navItem"><a href="../user/login.php" class="navA">Login </a></li>
                <li class="navItem"><a href="../user/register.php" class="navA">Register</a></li>
            </ul>
    ' ;
}
?>
<!DOCTYPE HTML>

<html lang="fr">

<head>
    <meta name="viewport" charset="UTF-8" content="width=device-width, initial-scale=1">
    <!--CSS CRÉER-->
    <link rel="stylesheet" href="../css/style.css">

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

    <!--Titre de la page-->
    <title> <?php echo $title ?></title>
</head>

<body class="fond-acueil">
    <!--entete-->
    <nav class="navbar">

        <?php
            echo $nav;
        ?>
    </nav>
    <div>
        <?php load_modules($view_array); ?>
    </div>

    <footer>
    </footer>
</body>

</html>