<?php
session_start();

require_once __DIR__ . "/../utils/utilbundle.php";
require_once __DIR__ . "/../classes/Inventaire/Inventaire.php";
require_once __DIR__ . "/../classes/Panier/Panier.php";
require_once __DIR__ . "/../classes/Items/ItemTDG.php";
require_once __DIR__ . "/../classes/Joueur/JoueurTDG.php";
require_once __DIR__ . "/../classes/Joueur/Joueur.php";


$sess_status = validate_session();

$required_sess_status = true;

if ($sess_status != $required_sess_status) {
    http_response_code(401);
    header("Location: ../user/login.php");
    die();
}

//quantite
if (isset($_GET["Quantite"]))
    $quantite = sanitize($_GET["Quantite"]);
else {
    echo ("trouve pas le get de quantite");
}

//idItem
if (isset($_GET["idItem"]))
    $idItem = sanitize($_GET["idItem"]);
else
    echo ("trouve pas le get de quantite");

//idJoeuur
$idJoueur = $_SESSION['userID'];

/*objets */
$inventaire = new Inventaire();
$panier = new Panier();
$joueur = new Joueur();

if ($inventaire->ajouter_item_inventaire($idItem, $idJoueur, $quantite)) {
    /*si on a réussit à ajouter l'item à l'inventaire
          on doit l'enlever du panier*/
    if (!$panier->supprimer_item_panier($idItem)) {
        header("Location: ../error.php?ErrorMSG=Bad%20request");
        die();
    }

    /*après on doit ajuster les gains du joeurs*/
    $TDGJoueur = JoueurTDG::getInstance();
    $res1 = $TDGJoueur->get_gains_by_id($idJoueur);
    $gainsJoueur = $res1['montantInitial'];

    $TDGItem = itemTDG::getInstance();
    $prixItem = $TDGItem->get_prix_by_id($idItem);

    /*total*/
    $total = $quantite * $prixItem;

    /*total du joueur*/
    $totalJoueur = $gainsJoueur - $total;
    
    /*soustraire le total aux gains du joueur*/
    if(!$joueur->update_user_montant($totalJoueur,$idJoueur) && $totalJoueur < $total){
        header("Location: ../user/inventaire.php?ErrorMSG=Gains%20insuffisants");
        die();
    }

    /*quantite*/
    $quantiteStock = $TDGItem->get_quantiteStock_by_id($idItem);
    $quantiteRestante = $quantiteStock - $quantite;

    /*soustraire la quantitedemande à la quantite en stock*/
    if(!$TDGItem->update_quantiteStock($idItem,$quantiteRestante)){
        header("Location: ../error.php?ErrorMSG=Bad%20request");
        die();
    }
}
else {
    header("Location: ../error.php?ErrorMSG=Bad%20request");
    die();
}

header("Location: ../user/inventaire.php");
die();