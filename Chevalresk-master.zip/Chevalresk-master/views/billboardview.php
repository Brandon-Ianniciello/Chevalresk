<div class="container">
    <h1 style="text-align: center;">ITEMS</h1>
</div>
<br>
<?php
$buyable = false;
if (validate_session()) {
    $buyable = true;
}

/*AFFICHER TOUT LES ITEMS*/
$TDG = itemTDG::getInstance();
$res = $TDG->get_all_items();
//$tableItems = html_table_gen($res);
$table = "<div class='container'>
<table id='itemTab'>";


foreach ($res as $column => $item) {
    $idItem = $item['idItem'];
    $table .= "<tr>";
    $table .= '<td id="data">' . $item['idItem'] . '</td>';
    $table .= '<td id="data">' . $item['nomItem'] . '</td>';
    $table .= '<td id="data">' . $item['quantiteStockItems'] . '</td>';
    $table .= '<td id="data">' .  $item['typeItem'] . ' </td>';
    $table .= '<td id="data">' . $item['prixItem'] . '</td>';
    $table .= '<td id="data"><img src="' . $item['photoItem'] . '"></td>';
    $table .= '<td><a href="../user/panier.php?id="' . $idItem .'">AJOUTER AU PANIER</a></td>';
    $table .= '</tr>';
}

$table .= ' </table>
 </div>';


echo $table;
?>