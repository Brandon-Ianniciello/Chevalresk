<div class="container">
    <h1 style="text-align: center;">ITEMS</h1>
</div>
<br>
<?php
$buyable = false;
if (validate_session()) {
    $buyable = true;
}

/*AFFICHER TOUT LES ITEMS*/
$TDG = itemTDG::getInstance();
$res = $TDG->get_all_items();
$tableItems = html_table_gen($res);
$item = $res[0];
?>

<div class="container">
    <table id='itemTab'>
        <tr>
           <td style='border:1px solid black;text-align:center;' id="data"><?php echo $item['idItem']?></td>
           <td id='data'><?php echo $item['nomItem']?></td>
           <td id="data"><?php echo $item['quantiteStockItems']?></td>
           <td id="data"><?php echo $item['typeItem']?></td>
           <td id="data"><?php echo $item['prixItem']?></td>
           <td id="data"><img src="<?php echo $item['photoItem']?>" alt=""></td>
        </tr>
    </table>
    <?php
    
    echo ($tableItems);
    ?>
</div>