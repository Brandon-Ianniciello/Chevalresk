<?php
    session_start();

    require_once __DIR__ . "/../utils/utilbundle.php";
    require_once __DIR__ . "/../classes/Joueur/Joueur.php";

    //regarde si la session est valide
    $sess_status = validate_session();

    // $required_sess_status = false; 

    // if($sess_status != $required_sess_status)
    // {
    //     http_response_code(401);
    //     echo ("error 401: unauthorized");
    //     die();
    // }

    $post_params = ["alias","nom","prénom", "email","password","confirmpassword"];
    validate_param($_POST, $post_params);

    $alias = sanitize($_POST["alias"]);
    $prénom = sanitize($_POST['prénom']);
    $nom = sanitize($_POST['nom']);
    $email = sanitize($_POST['email']);
    $pw = sanitize($_POST['password']);
    $cpw = sanitize($_POST['confirmpassword']);

    /*Regarde si l'email est valide*/
    if(!validate_email($email)){
        header("Location: ../user/register.php?errmsg=Invalid Email");
        die();
    }

    /*Regarde si le mdp est valide*/
    if(!validate_password($pw)){
        header("Location: ../user/register.php?errmsg=Invalid Password : Must contains 1 number,1 special var and 6 characters");
        die();
    }

    $joueur = new Joueur();

    if(!$joueur->register($alias,$prénom,$nom,$email, $pw, $cpw))
    {
        echo "\nca marche pas ";
        var_dump($alias);
        var_dump($prénom);
        var_dump($nom);
        var_dump($email);
        var_dump($pw);
        var_dump($cpw);
        //header("Location: ../user/login.php?errmsg=Invalid credentials");
        //die();
    }
    else
        echo "ca marche ";

    //header("Location: ../user/login.php");
    //die();