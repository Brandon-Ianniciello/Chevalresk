<?php
$username = strtoupper($_SESSION["userName"]); //en majuscule
?>

<div class="container">
<form class="form-signin" method="POST" action="../user.dom/ajusterSolde.dom.php">

    <h2 style="text-align: center;">
        AJUSTER LE SOLDE D'UN JOUEUR PAR <?php echo $username; ?>
    </h2>
    <div class="pt-3">
        <input type="text" id="alias" name="alias" class="form-control" placeholder="Alias du Joueur" required autofocus>
    </div>
   
    <button class="btn btn-lg btn btn-dark btn-block mt-3" type="submit">AJUSTER</button>
</form>
</div>