<?php
$username = strtoupper($_SESSION["userName"]); //en majuscule
?>

<div class="container">
<form class="form-signin" method="POST" action="../user.dom/ajusterSolde.dom.php">

    <h2 style="text-align: center;">
        AJUSTER ADMINISTRATIVEMENT LE SOLDE D'UN JOUEUR PAR <?php echo $username; ?>
    </h2>
    <div class="pt-3">
        <input type="text" id="alias" name="alias" class="form-control" placeholder="Alias du Joueur à ajuster" required autofocus>
    </div>

    <div class="pt-3">
        <input type="text" id="montant" name="montant" class="form-control" placeholder="montant du Joueur à ajuster" required autofocus>
    </div>
   
    <button class="btn btn-lg btn btn-dark btn-block mt-3" type="submit">AJUSTER</button>
</form>
</div>