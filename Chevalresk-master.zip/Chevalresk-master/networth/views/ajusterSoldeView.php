<?php
$username = strtoupper($_SESSION["userName"]); //en majuscule
?>

<div class="container">
<form class="form-signin" method="POST" action="../user.dom/deleteitem.dom.php">

    <h2 style="text-align: center;">
        AJUSTER LE SOLDE D'UN JOUEUR PAR <?php echo $username; ?>
    </h2>
    <div class="pt-3">
        <input type="text" id="nomItem" name="nomJoueur" class="form-control" placeholder="Nom de l'item" required autofocus>
    </div>
   
    <div class="pt-3">
        <input type="text" id="typeItem" name="typeItem" class="form-control" placeholder="Type de l'item" required autofocus>
    </div>
    
    <button class="btn btn-lg btn btn-danger btn-block mt-3" type="submit">SUPPRIMER</button>
</form>
</div>