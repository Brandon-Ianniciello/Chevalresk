<?php
$username = strtoupper($_SESSION["userName"]); //en majuscule
?>

<h1 style="text-align: center;">
    INVENTAIRE DE <?php echo $username; ?>
</h1>
<hr>
<?php
//afficher l'error si y'en a une
if (isset($_GET['ErrorMSG'])) {
    $msg_error = $_GET['ErrorMSG'];
    echo "<div class='pt-3 text-danger'>
        <h5>$msg_error</h5>
    </div>";
}
?>
</hr>

<br><br>

<div class="container">
    <h4>Article dans votre inventaire présentement</h4>

    <div style="border: 2px solid black;">
        <?php
        $idJoueur = $_SESSION["userID"];

        $inventaire = InventaireTDG::getInstance();
        $itemTDG = itemTDG::getInstance();
        $nbrItemsInventaire = 0;
        $items = $inventaire->get_all_info_by_id($idJoueur);

        $table = "<div class='container'><table id='itemTab'>";

        //si l'inventaire est vide
        if (empty($items)) {
            $table .= "<tr><th>Aucun article présentement :(</th></tr>";
        } 
        //si l'inventaire contient un item
        else if(isset($items)){
            $table .= "<tr style='text-align:center;'><th>Nom</th><th>Quantite en stock</th><th>Quantite voulue</th><th>Type</th><th>Prix</th><th>Image</th><th></th></tr>";

            foreach ($items as $idItem) {
                $id = $idItem['idItem'];
                $res = $itemTDG->get_all_info_by_id($id);
                $quantite = $inventaire->get_quantite_by_idItem($id);
                $quantite = ($quantite['Quantite']);
                foreach ($res as $column => $item) {
                    $idItem = $item['idItem'];
                    $table .= "<tr>";
                    $table .= '<td id="data">' . $item['nomItem'] . '</td>';
                    $table .= '<td id="data">' . $item['quantiteStockItems'] . '</td>';
                    $table .= "<td style='color:red;' id='data'>$quantite</td>";
                    $table .= '<td id="data">' .  $item['typeItem'] . ' </td>';
                    $table .= '<td id="data">' . $item['prixItem'] . '</td>';
                    $table .= '<td id="data"><a href="' . $item['photoItem'] . '"><img class="imageItem" src="' . $item['photoItem'] . '"></a></td>';
                    $table .= "<td id='data'><a href='../user.dom/deleteinventaire.dom.php?idItem=$idItem'><h5>SUPPRIMER</h5></a></td>";
                    $table .= '</tr>';

                    $nbrItemsInventaire++;
                }
            }
        }
        if(isset($_SESSION["nbrItemsPanier"]))
            $_SESSION["nbrItemsPanier"] = $nbrItemsInventaire;
        $table .= ' </table></div>';
        echo $table;
        ?>
    </div>

    <a href="../user/billboard.php">Retourner à la liste</a>
</div>
</hr>