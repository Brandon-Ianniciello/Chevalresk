<?php
$username = strtoupper($_SESSION["userName"]); //en majuscule
?>

<h1 style="text-align: center;">
    INVENTAIRE DE <?php echo $username; ?>
</h1>
<hr>
<?php
//afficher l'error si y'en a une
if (isset($_GET['ErrorMSG'])) {
    $msg_error = $_GET['ErrorMSG'];
    echo "<div class='pt-3 text-danger'>
        <h5>$msg_error</h5>
    </div>";
}
?>
</hr>

<br><br>

<div class="container">
    <h4>Article dans votre inventaire présentement</h4>

    <div style="border: 2px solid black;">
        <?php
        $idJoueur = $_SESSION["userID"];

        /* Inventaire */
        $inventaire = InventaireTDG::getInstance();
        $itemTDG = itemTDG::getInstance();
        $nbrItemsInventaire = 0;
        $items = $inventaire->get_all_info_by_id($idJoueur);

        $table = "<div class='container'><table id='itemTab'>";

        //si l'inventaire est vide
        if (empty($items)) {
            $table .= "<tr><th>Aucun article présentement :(</th></tr>";
        }
        //si l'inventaire contient un item
        else if (isset($items)) {
            $table .= "<tr style='text-align:center;'><th>Nom</th><th>Quantite en stock</th><th>Quantite voulue</th><th>Type</th><th>Prix</th><th>Image</th><th></th></tr>";

            foreach ($items as $idItem) {
                $id = $idItem['idItem'];
                $res = $itemTDG->get_all_info_by_id($id);
                $quantite = $inventaire->get_quantite_by_idItem($id);
                $quantite = ($quantite['Quantite']);

                /* Évaluations */
                $évalTDG = EvaluationTDG::getInstance();
                $evaluations = $évalTDG->get_all_info_by_idItem($id);

                foreach ($res as $column => $item) {
                    $idItem = $item['idItem'];
                    $table .= "<tr>";
                    $table .= '<td id="data">' . $item['nomItem'] . '</td>';
                    $table .= '<td id="data">' . $item['quantiteStockItems'] . '</td>';
                    $table .= "<td style='color:red;' id='data'>$quantite</td>";
                    $table .= '<td id="data">' .  $item['typeItem'] . ' </td>';
                    $table .= '<td id="data">' . $item['prixItem'] . '</td>';
                    $table .= '<td id="data"><a href="' . $item['photoItem'] . '"><img class="imageItem" src="' . $item['photoItem'] . '"></a></td>';
                    $table .= "<td id='data'><a href='../user.dom/deleteinventaire.dom.php?idItem=$idItem'><h5>SUPPRIMER</h5></a></td>";
                    $table .= '</tr>';

                    /*ajouter une évaluation*/
                    $table .= '<tr style="text-align:center;">';
                    $table .= '<td>
                    <form method="POST" action="../user.dom/addEvalutations.dom.php?idItem='. $idItem .'">
                        <tr>
                            <td id="data">
                                <h4>Ajouter un commentaire</h4>
                                <input type="text" name="commentaire" placeholder="Commentez ici..." required autofocus>
                            </td>
                        </tr>
                        <tr>
                           <td id="data">
                                <h4>Rating</h4>
                                <div class="rate">
                                    <input type="radio" id="star5" name="rate" value="5" required autofocus/>
                                    <label for="star5" title="text">5 stars</label>
                                    <input type="radio" id="star4" name="rate" value="4" required autofocus/>
                                    <label for="star4" title="text">4 stars</label>
                                    <input type="radio" id="star3" name="rate" value="3" required autofocus/>
                                    <label for="star3" title="text">3 stars</label>
                                    <input type="radio" id="star2" name="rate" value="2" required autofocus/>
                                    <label for="star2" title="text">2 stars</label>
                                    <input type="radio" id="star1" name="rate" value="1" required autofocus/>
                                    <label for="star1" title="text">1 star</label>
                                </div>
                           </td>
                           <td id="data"><input class="" value="Évaluez" type="submit" name="submitRating"></td>
                        </tr>
                    </form></td>';

                    $table .= '</tr>';
                    $nbrItemsInventaire++;

                }
            }
        }
        if (isset($_SESSION["nbrItemsInventaire"]))
            $_SESSION["nbrItemsInventaire"] = $nbrItemsInventaire;
        $table .= ' </table></div>';
        echo $table;

        ?>
    </div>
    <br>
    <a href="../user/billboard.php">Retourner à la liste</a>
</div>
</hr>