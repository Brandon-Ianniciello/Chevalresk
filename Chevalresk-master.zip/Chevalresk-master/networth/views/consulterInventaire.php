<h2>CONSULTATION ADMINISTRATIVE D'UN INVENTAIRE PAR   <?PHP echo(strtoupper($_SESSION["userName"]));?>  </h2>

<div class="container">
    <form class="form-signin" method="POST" action="../user/inventaire.php?isAdmin=true">
        <div class="pt-3">
            <input type="text" id="alias" name="alias" class="form-control" placeholder="Alias du Joueur à rechercher..." required autofocus>
        </div>

        <button class="btn btn-lg btn btn-dark btn-block mt-3" type="submit">CONSULTER</button>
    </form>
</div>
