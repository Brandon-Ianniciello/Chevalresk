<div class="divSearch">
    <h4 class="categorieRecherche">Recherche par categorie:</h4>
    <nav class="rechercheCat">
        <a href="../user/billboard.php" class="itemCat">Tous les items</a>
        <a href="../user/potion.php" class="itemCat">Potion</a>
        <a href="../user/arme.php" class="itemCat">Armes</a>
        <a href="../user/armure.php" class="itemCat">Armures</a>
    </nav>
   
    <table class='tableRecherche'>
        <tr class="recherchePos">
            <?php
            if (isset($_SESSION['userID']))
                $idJoueur = $_SESSION['userID'];
            else
                $idJoueur = null;

            /*Voir si l'internaute est l'administrateur*/
            $TDG = JoueurTDG::getInstance();
            $isAdmin = $TDG->get_isAdmin_by_id($idJoueur);

            if ($isAdmin == 1) {
                echo "
                <td><a href='../user/addItem.php'>AJOUTER UN ITEM</a></td>
                <td><a href='../user/deleteItem.php'>SUPPRIMER UN ITEM</a></td>
                <td><a href='../user/ajusterSoldeJoueur.php'>AJUSTER SOLDE D'UN JOUEUR</a></td>
            ";
            }
            ?>
            <td>
                <form method='POST'>
                    <label>Recherche</label>
                    <input type='text' name='txtBox' required autofocus>
                    <input type='submit' name='search' class='recherche-btn' value="Rechercher" placeholder="Écrire ici pour faire une recherche">
                </form>
            </td>
        </tr>
    </table>
    <h3 class='intro'>TOUS LES ITEMS</h3>
</div>
<br>

<?php
$buyable = false;
if (validate_session()) {
    $buyable = true;
}

//afficher l'error si y'en a une
if (isset($_GET['ErrorMSG'])) {
    $msg_error = $_GET['ErrorMSG'];
    echo "<div class='pt-3 text-danger'>
        <h5>$msg_error</h5>
    </div>";
}

/*Variables */
$TDG = itemTDG::getInstance();
if (isset($_SESSION['userID']))
    $idJoueur = $_SESSION['userID'];
else
    $idJoueur = null;

/*Si il y a une recherche*/
if (isset($_POST['search'])) {
    $recherche = $_POST['search'];
    $itemName = $TDG->get_by_nom($_POST['txtBox']);
    $res = $TDG->get_all_info_by_name($itemName);
    $table = "<div class='container'><h4 class='sous-titre'>RÉSULTAT POUR LA RECHERCHE :</h4>";
    
    foreach ($res as $column => $item) {
        $table .= "<div class='col-4'>";
        $table .= "<div class='col'>";
        $idItem = $item['idItem'];
        $table .= '<img class="imageItem" src="' . $item['photoItem'] . '">';
        if ($item['quantiteStockItems'] <= 0){
            $table .= '<h4 id="data"><a style="color:red;">RUPTURE DE STOCK</a></h4>';
            $table .= '<h4 class="nomItem">' . $item['nomItem'] . '</h4><p class="prixItem">' . $item['prixItem'] . '$</p>';
        }
       
        else{
            $table .= '<h4 class="nomItem">' . $item['nomItem'] . '</h4><p class="prixItem">' . $item['prixItem'] . '$</p>';    $table .= "<a class='addPanier' href='../user/panier.php?id=$idItem idJoueur=$idJoueur'>AJOUTER AU PANIER</a>";
            $table .= '<h4 class="qtStock">Quantité en stock:' . $item['quantiteStockItems'] . '</h4>';
        }     

    $table .= '</div> </div>';
    }
    $table .= ' </table></div>';
    echo $table;
}
?>

<?php
if(!isset($_POST['search'])){
    $res = $TDG->get_all_items();
    $table = "<div class='row'>";
    foreach ($res as $column => $item) {
        $table .= "<div class='col-4'>";
        $table .= "<div class='col'>";
        $idItem = $item['idItem'];
        $table .= '<img class="imageItem" src="' . $item['photoItem'] . '">';
        if ($item['quantiteStockItems'] <= 0){
            $table .= '<h4 id="data"><a style="color:red;">RUPTURE DE STOCK</a></h4>';
            $table .= '<h4 class="nomItem">' . $item['nomItem'] . '</h4><p class="prixItem">' . $item['prixItem'] . '$</p>';
        }
       
        else{
            $table .= '<h4 class="nomItem">' . $item['nomItem'] . '</h4><p class="prixItem">' . $item['prixItem'] . '$</p>';    $table .= "<a class='addPanier' href='../user/panier.php?id=$idItem idJoueur=$idJoueur'>AJOUTER AU PANIER</a>";
            $table .= '<h4 class="qtStock">Quantité en stock:' . $item['quantiteStockItems'] . '</h4>';
        }     

    $table .= '</div> </div>';
    
    }

    $table .= ' </table></div>';
    echo $table;
}
?>