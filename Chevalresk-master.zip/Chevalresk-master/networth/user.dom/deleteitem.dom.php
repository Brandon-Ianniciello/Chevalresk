<?php
    session_start();

    require_once __DIR__ . "/../utils/utilbundle.php";
    require_once __DIR__ . "/../classes/Items/Item.php";
    require_once __DIR__ . "/../classes/Items/ItemTDG.php";

    $sess_status = validate_session();

    $required_sess_status = true; 

    if($sess_status != $required_sess_status)
    {
        http_response_code(401);
        header("Location: ../user/login.php");
        die();
    }

    $post_params = ["nomItem","typeItem"];
    validate_param($_POST, $post_params);

    $nomItem = sanitize($_POST["nomItem"]);
    $type = sanitize($_POST["typeItem"]);

    $item = new Item();

    if(!$item->supprimer_item($nomItem,$type)){
        //header("Location: ../error.php?ErrorMSG=Bad%20request");
        //die();
    }
   
    // header("Location: ../user/billboard.php");
    // die();
?>