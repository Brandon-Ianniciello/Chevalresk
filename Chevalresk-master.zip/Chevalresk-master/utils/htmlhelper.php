<?php

function html_table_gen($sql_result)
{
    $resp = "<table id='itemTab'>";

    $resp .= "<tr>";

    $temp = $sql_result[0];
    //Titre des colonnes
    foreach ($temp as $key => $data) {
        $resp .= "<th  style='border:1px solid black;text-align:center;'>$key</th>";
        
    }

    $resp .= "</tr>";

    // start row
    $resp .= "<tr>";
    //print out cell data
    foreach ($temp as $data) {
        $resp .= "
        <td style='border:1px solid black;text-align:center;>
            <span style='margin:10px;'>
                $data
            </span>
        </td>";
    }

    //close row
    $resp .= "</tr>";

    $resp .= "</table>";

    return $resp;
}
