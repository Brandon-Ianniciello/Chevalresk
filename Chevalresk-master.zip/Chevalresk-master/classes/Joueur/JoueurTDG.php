<?php

include_once __DIR__ . "/../../utils/connector.php";

class JoueurTDG extends DBAO
{
    private $tableName;
    private static $_instance = null;

    private function __construct()
    {
        Parent::__construct();
        $this->tableName = "Joueurs";
    }

    public static function getInstance()
    {

        if (is_null(self::$_instance))
            $_instance = new JoueurTDG();

        return $_instance;
    }

    public function get_all_info_by_id($id)
    {
        try {
            $conn = $this->connect();
            $tableName = $this->tableName;
            $query = "SELECT * FROM $tableName WHERE idJoueur=:idJoueur";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':idJoueur', $id);
            $stmt->execute();
            $stmt->setFetchMode(PDO::FETCH_ASSOC);
            $result = $stmt->fetchAll();
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
        $conn = null;
        return $result;
    }

    public function get_by_id($id)
    {

        try {
            $conn = $this->connect();
            $tableName = $this->tableName;
            $query = "SELECT idJoueur FROM $tableName WHERE idJoueur=:idJoueur";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':idJoueur', $id);
            $stmt->execute();
            $stmt->setFetchMode(PDO::FETCH_ASSOC);
            $result = $stmt->fetch();
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
        $conn = null;
        return $result;
    }

    public function get_id_by_email($email)
    {
        try {
            $conn = $this->connect();
            $tableName = $this->tableName;
            $query = "SELECT idJoueur FROM $tableName WHERE courriel =:courriel";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':courriel', $email);
            $stmt->execute();
            $stmt->setFetchMode(PDO::FETCH_ASSOC);
            $result = $stmt->fetchAll();
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
        $conn = null;
        return $result;
    }

    public function get_by_email($email)
    {

        try {
            $conn = $this->connect();
            $tableName = $this->tableName;
            $query = "SELECT courriel FROM $tableName WHERE courriel =:courriel";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':courriel', $email);
            $stmt->execute();
            $stmt->setFetchMode(PDO::FETCH_ASSOC);
            $result = $stmt->fetch();
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
        $conn = null;
        return $result;
    }


    public function get_by_alias($alias)
    {

        try {
            $conn = $this->connect();
            $tableName = $this->tableName;
            $query = "SELECT alias FROM $tableName WHERE alias=:alias";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':alias', $alias);
            $stmt->execute();
            $stmt->setFetchMode(PDO::FETCH_ASSOC);
            $result = $stmt->fetchAll();
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
        $conn = null;
        return $result;
    }


    public function get_all_users()
    {

        try {
            $conn = $this->connect();
            $tableName = $this->tableName;
            $query = "SELECT * FROM $tableName";
            $stmt = $conn->prepare($query);
            $stmt->execute();
            $stmt->setFetchMode(PDO::FETCH_ASSOC);
            $result = $stmt->fetchAll();
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
        $conn = null;
        return $result;
    }


    public function add_user($alias, $nom, $prénom, $motDepasse, $courriel, $montantInitial, $isAdmin)
    {
        $id = "DEFAULT";
        try {
            $conn = $this->connect();
            $tableName = $this->tableName;
            $query = "INSERT INTO $tableName VALUES (:idJoueur,:alias, :nom,:prénom,
            :motDePasse, :courriel,:montantInitial,:isAdmin);";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':idJoueur', $id);
            $stmt->bindParam(':alias', $alias);
            $stmt->bindParam(':nom', $nom);
            $stmt->bindParam(':prénom', $prénom);
            $stmt->bindParam(':motDepasse', $motDepasse);
            $stmt->bindParam(':courriel', $courriel);
            $stmt->bindParam(':montantInitial', $montantInitial);
            $stmt->bindParam(':isAdmin', $isAdmin);
            $stmt->execute();
            $resp = true;
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
            $resp = false;
        }
        $conn = null;
        return $resp;
    }

    /*
      update juste pour les infos
    */
    public function update_info($email, $username, $id)
    {

        try {
            $conn = $this->connect();
            $tableName = $this->tableName;
            $query = "UPDATE $tableName SET courriel=:courriel, alias=:alias WHERE idJoueur=:idJoueur";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':courriel', $email);
            $stmt->bindParam(':alias', $username);
            $stmt->bindParam(':idJoueur', $id);
            $stmt->execute();
            $resp = true;
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
            $resp = false;
        }
        $conn = null;
        return $resp;
    }

    /*
      update juste pour le password
    */
    public function update_password($NPW, $id)
    {

        try {
            $conn = $this->connect();
            $tableName = $this->tableName;
            $query = "UPDATE $tableName SET motDePasse=:motDePasse WHERE idJoueur=:idJoueur";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':motDePasse', $NPW);
            $stmt->bindParam(':idJoueur', $id);
            $stmt->execute();
            $resp = true;
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
            $resp = false;
        }
        $conn = null;
        return $resp;
    }
}
