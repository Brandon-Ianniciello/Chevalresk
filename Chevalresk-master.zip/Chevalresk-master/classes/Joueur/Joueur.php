<?php
include_once __DIR__ . "/JoueurTDG.php";

class Joueur{

    private $idJoueur;
    private $alias;
    private $nom;
    private $prénom;
    private $mdpCrypte;
    private $courriel;
    private $montantInitial;
    private $isAdmin;

    /*Constructeur*/
    public function __construct(){}

    /*Getters*/
    public function get_id(){
        return $this->idJoueur;
    }

    public function get_courriel(){
        return $this->courriel;
    }

    public function get_alias(){
        return $this->alias;
    }

    public function get_mdpCrypte(){
        return $this->mdpCrypte;
    }

    public function get_nom(){
        return $this->nom;
    }

    public function get_prénom(){
        return $this->prénom;
    }

    public function get_montantInitial(){
        return $this->montantInitial;
    }

    public function get_isAdmin(){
        return $this->isAdmin;
    }

    /*Setters*/
    public function set_courriel($courriel){
        $this->courriel = $courriel;
    }

    public function set_nom($nom){
        $this->nom = $nom;
    }

    public function set_prénom($prénom){
        $this->prénom = $prénom;
    }

    public function set_alias($alias){
        $this->alias = $alias;
    }

    public function set_mdpCrypte($mdpCrypte){
        $this->mdpCrypte = $mdpCrypte;
    }

    public function load_user($id)
    {
        $TDG = JoueurTDG::getInstance();
        $res = $TDG->get_all_info_by_id($id);
        $joueur = $res[0];//on prends seulement le premier joueur
        $this->idJoueur = $joueur['idJoueur'];
        $this->courriel = $joueur['courriel'];
        $this->alias = $joueur['alias'];
        $this->nom = $joueur['nom'];
        $this->prénom = $joueur['prénom'];
        $this->montantInitial = $joueur['montantInitial'];
        $this->mdpCrypte = $joueur['motDePasse'];
        $this->isAdmin = $joueur['isAdmin'];

        $TDG = null;
        return true;
    }


    public function login($email, $pw){
        $TDG = JoueurTDG::getInstance();
        $res = $TDG->get_id_by_email($email);
        $res = $res[0];
        $id = $res['idJoueur']; 
        $joueur = $this->load_user($id);
        var_dump($TDG->get_all_info_by_id($id));
        var_dump($joueur);
        if(!$joueur)
        {
            return false;
        }
        if(!password_verify($pw, $this->mdpCrypte))
        {   
            var_dump($pw, $this->mdpCrypte);
            echo('le mot de passe correspond pas avec le crypté');
            return false;
        }
        return true;
    }

    //Register Validation
    public function validate_email_not_exists($email){
        $TDG = JoueurTDG::getInstance();
        $res = $TDG->get_by_email($email);//retourne seulement le email juste de meme lala
        $TDG = null;
        if($res)
        {
            return false;
        }

        return true;
    }

    public function validate_username_not_exists($username){
        $TDG = JoueurTDG::getInstance();
        $res = $TDG->get_by_email($username);//retourne seulement le email juste de meme lala
        $TDG = null;
        if($res)
        {
            return false;
        }

        return true;
    }

    public function register($alias,$prénom,$nom,$email, $pw, $vpw){
        $montantInitial = 500;
        $isAdmin = 0;//définit l'admin direct dans la bd

        if(!($pw === $vpw) || empty($pw) || empty($vpw))
        {
            echo("mot de passe invalides");
            return false;
        }
        //crypté le mdp
        else{
            
            $pw= password_hash($pw, PASSWORD_DEFAULT);
            var_dump($pw);
        }

        //check if email is used
        if(!$this->validate_email_not_exists($email))
        {
            echo("email déja use");
            return false;
        }

        //add user to DB
        $TDG = JoueurTDG::getInstance();
        $res = $TDG->add_user($alias,$nom,$prénom,$pw,$email,$montantInitial,$isAdmin);
        $TDG = null;
        return $res;
    }

    public function update_email_info($email, $newmail){

        //load user infos
        if(!$this->load_user($email))
        {
          return false;
        }

        if(empty($this->idJoueur) || empty($newmail)){
          return false;
        }

        //check if email is already used
        if(!$this->validate_email_not_exists($newmail) && $email != $newmail)
        {
            return false;
        }

        $this->email = $newmail;

        $TDG = JoueurTDG::getInstance();
        $res = $TDG->update_info($this->courriel, $this->alias, $this->idJoueur);

        if($res){
          $_SESSION["userEmail"] = $this->courriel;
        }

        $TDG = null;
        return $res;
    }

    public function update_username_info($name,$newUsername,$email){

        //load user infos
        if(!$this->load_user($email))
        {
          return false;
        }

        if(empty($this->idJoueur) || empty($newUsername)){
          return false;
        }

        //check if email is already used
        if(!$this->validate_username_not_exists($newUsername) && $name != $newUsername)
        {
            return false;
        }

        $this->alias=$newUsername;

        $TDG = JoueurTDG::getInstance();
        $res = $TDG->update_info($this->courriel, $this->alias, $this->idJoueur);

        if($res){
          $_SESSION["userName"] = $this->alias;
        }

        $TDG = null;
        return $res;
    }

   
    public function update_user_pw($email, $oldpw, $pw, $pwv){

        if(!$this->load_user($email))
        {
          return false;
        }

        if(empty($pw) || $pw != $pwv){
          return false;
        }

        if(!password_verify($oldpw, $this->passwordhash))
        {
            return false;
        }

        $TDG = JoueurTDG::getInstance();
        $NHP = password_hash($pw, PASSWORD_DEFAULT);
        $res = $TDG->update_password($NHP, $this->id);
        $this->mdpCrypte = $NHP;
        $TDG = null;
        return $res;
    }

    public function display()
    {
        $id = $this->idJoueur;
        include "userview.php";//pas le bon path jpense moi la
    }
}
