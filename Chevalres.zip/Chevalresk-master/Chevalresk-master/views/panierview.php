<?php
$username = strtoupper($_SESSION["userName"]); //en majuscule
?>
<h1 style="text-align: center;">
    PANIER DE <?php echo $username; ?>
</h1>

<?php
//si un article est voulue ajouter au panier
if (isset($_GET['id']) || !empty($_GET['id'])) {
    $id = $_GET['id'];
    echo '<h4>VOULEZ VOUS AJOUTER CET ITEM DANS VOTRE PANIER ?<a href="">OUI </a><a href="../user/billboard.php"> NON</a></h4>';

    $TDG = itemTDG::getInstance();
    $res = $TDG->get_all_info_by_id($id);
    $table = "<div class='container'><table id='itemTab'>";

    foreach ($res as $column => $item) {
        $idItem = $item['idItem'];
        $table .= "<tr>";
        $table .= '<td id="data">' . $item['idItem'] . '</td>';
        $table .= '<td id="data">' . $item['nomItem'] . '</td>';
        $table .= '<td id="data">' . $item['quantiteStockItems'] . '</td>';
        $table .= '<td id="data">' .  $item['typeItem'] . ' </td>';
        $table .= '<td id="data">' . $item['prixItem'] . '</td>';
        $table .= '<td id="data"><a href="' . $item['photoItem'] . '"><img src="' . $item['photoItem'] . '"></a></td>';
        $table .= '</tr>';
    }

    $table .= ' </table>
 </div>';

    echo $table;
}

?>

<?php

?>

<div class="container">
    <h4>Article dans votre panier présentement</h4>
    <?php

    //aller chercher le panier du joueur avec son 
    $idJoueur = $_SESSION["userID"];
    $inventaire = InventaireTDG::getInstance();
    $idItem = $inventaire->get_by_id($idJoueur);//à remplacer par le vrai id

    $TDG = itemTDG::getInstance();
    $item = $TDG->get_all_info_by_id(1);
    $panier = html_table_gen($item);

    echo $panier;
    ?>
    <a href="">
        <h5>ACHETER</h5>
    </a><a href="">
        <h5>SUPPRIMER</h5>
    </a>
</div>