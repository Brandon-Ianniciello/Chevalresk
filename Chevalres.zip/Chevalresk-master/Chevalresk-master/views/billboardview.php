<div class="container">
    <table>
        <tr>
            <td><a href="../user/potion.php">POTIONS</a></td>
            <th>ITEMS</th>
            <td><a href="../user/armure.php">ARMURES</a></td>
            <td></td>
            <td><a href="../user/arme.php">ARMES</a></td>
            <td></td>
            <td><a href="../user/addItem.php">AJOUTER UN ITEM</a></td>
        </tr>
        <tr>
            <td>
                <form method='POST'>
                    <nav class='nav-item'>
                        <div class='input-group mb-3'>
                            <input type='text' name='txtBox'>
                            <input type='submit' name='search' class='btn btn-success'><img class='loupe'>
                        </div>
                    </nav>
                </form>
            </td>
        </tr>
    </table>
</div>
<br>

<?php
$buyable = false;
if (validate_session()) {
    $buyable = true;
}

$TDG = itemTDG::getInstance();

/*Si il y a une recherche*/
if (isset($_POST['search'])) {
    $itemName = $TDG->get_by_nom($_POST['txtBox']);
    $res = $TDG->get_all_info_by_name($itemName);

    $table = "<div class='container'><table id='itemTab'>";
    foreach ($res as $column => $item) {
        $idItem = $item['idItem'];
        $table .= "<tr>";
        $table .= '<td id="data">' . $item['idItem'] . '</td>';
        $table .= '<td id="data">' . $item['nomItem'] . '</td>';
        $table .= '<td id="data">' . $item['quantiteStockItems'] . '</td>';
        $table .= '<td id="data">' .  $item['typeItem'] . ' </td>';
        $table .= '<td id="data">' . $item['prixItem'] . '</td>';
        $table .= '<td id="data"><a href="' . $item['photoItem'] . '"><img class="imageItem" src="' . $item['photoItem'] . '"></a></td>';
        $table .= "<td><a href='../user/panier.php?id=$idItem'>AJOUTER AU PANIER</a></td>";
        $table .= '</tr>';
    }
    $table .= ' </table></div>';
    echo $table;
}
?>

<h3 style="text-align: center;">TOUS LES ITEMS</h3>

<?php
$res = $TDG->get_all_items();
$table = "<div class='container'><table id='itemTab'>";
$table .= "<tr style='text-align:center;'><th>Nom</th><th>Quantite en stock</th><th>Type</th><th>Prix</th><th>Image</th><th></th></tr>";
foreach ($res as $column => $item) {
    $idItem = $item['idItem'];
    $table .= "<tr>";
    $table .= '<td id="data">' . $item['nomItem'] . '</td>';
    $table .= '<td id="data">' . $item['quantiteStockItems'] . '</td>';
    $table .= '<td id="data">' .  $item['typeItem'] . ' </td>';
    $table .= '<td id="data">' . $item['prixItem'] . '</td>';
    $table .= '<td id="data"><a href="' . $item['photoItem'] . '"><img class="imageItem" src="' . $item['photoItem'] . '"></a></td>';
    $table .= "<td><a href='../user/panier.php?id=$idItem'>AJOUTER AU PANIER</a></td>";
    $table .= '</tr>';
}

$table .= ' </table></div>';
echo $table;

?>