<div class="container">
    <table>
        <tr>
            <td><a href="../user/potion.php">POTIONS</a></td>
            <th>ITEMS</th>
            <td><a href="../user/armure.php">ARMURES</a></td>
            <td><a href="../user/arme.php">ARMES</a></td>
        </tr>
        <tr>
            <td><a href="../user/addItem.php">AJOUTER UN ITEM</a></td>
        </tr>
    </table>
</div>
<br>

<?php
$buyable = false;
if (validate_session()) {
    $buyable = true;
}

/*AFFICHER TOUT LES ITEMS*/
$TDG = itemTDG::getInstance();
$res = $TDG->get_all_items();
$table = "<div class='container'>
<table id='itemTab'>";


foreach ($res as $column => $item) {
    $idItem = $item['idItem'];
    $table .= "<tr>";
    $table .= '<td id="data">' . $item['idItem'] . '</td>';
    $table .= '<td id="data">' . $item['nomItem'] . '</td>';
    $table .= '<td id="data">' . $item['quantiteStockItems'] . '</td>';
    $table .= '<td id="data">' .  $item['typeItem'] . ' </td>';
    $table .= '<td id="data">' . $item['prixItem'] . '</td>';
    $table .= '<td id="data"><a href="' . $item['photoItem'] . '"><img src="' . $item['photoItem'] . '"></a></td>';
    $table .= "<td><a href='../user/panier.php?id='$idItem'>AJOUTER AU PANIER</a></td>";
    $table .= '</tr>';
}

$table .= ' </table>
 </div>';


echo $table;
?>