<?php
// $id = $_GET['id'];
$id = 1;
$username = strtoupper($_SESSION["userName"]);//en majuscule
?>

<h1 style="text-align: center;">
    PANIER DE <?php echo $username;?>
</h1>

<h4>VOULEZ VOUS AJOUTER CET ITEM DANS VOTRE PANIER ?<a href="">OUI </a><a href=""> NON</a></h4>

<?php
$TDG = itemTDG::getInstance();
$res = $TDG->get_all_info_by_id($id);
$table = "<div class='container'>
<table id='itemTab'>";

foreach ($res as $column => $item) {
    $idItem = $item['idItem'];
    $table .= "<tr>";
    $table .= '<td id="data">' . $item['idItem'] . '</td>';
    $table .= '<td id="data">' . $item['nomItem'] . '</td>';
    $table .= '<td id="data">' . $item['quantiteStockItems'] . '</td>';
    $table .= '<td id="data">' .  $item['typeItem'] . ' </td>';
    $table .= '<td id="data">' . $item['prixItem'] . '</td>';
    $table .= '<td id="data"><a href="' . $item['photoItem'] . '"><img src="' . $item['photoItem'] . '"></a></td>';
    $table .= '</tr>';
}

$table .= ' </table>
 </div>';


echo $table;
?>

<h4>Article dans votre panier présentement</h4>
<div class="container">
<?php
    $inventaire = InventaireTDG::getInstance();
    $articleDansPanier = $inventaire->get_all_inventaire();
    $panier = html_table_gen($articleDansPanier);

    echo $panier;
?>
<a href=""><h5>ACHETER</h5></a><a href=""><h5>SUPPRIMER</h5></a>
</div>